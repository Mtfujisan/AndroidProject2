package rs.f16csc413p2;

public class Test {
    public static final String TAG = "Project2";
}
