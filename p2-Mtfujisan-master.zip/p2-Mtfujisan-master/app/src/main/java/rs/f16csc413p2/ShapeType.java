package rs.f16csc413p2;

/**
 * Types of shapes the ShapeFactory can draw
 */
public enum ShapeType {
    CIRCLE, RECTANGLE, PICTURE
}
