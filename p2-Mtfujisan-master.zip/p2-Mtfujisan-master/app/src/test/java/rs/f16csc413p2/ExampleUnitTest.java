package rs.f16csc413p2;

import org.junit.Test;

import static org.junit.Assert.*;

import android.test.mock.MockContext;
import android.content.Context;
import android.util.Log;


/**
 * To work on unit tests, switch the Test Artifact in the Build Variants view.
 */
public class ExampleUnitTest {
    private static final String TAG = "Project 2";


    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }
}